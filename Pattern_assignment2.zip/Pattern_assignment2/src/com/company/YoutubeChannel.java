package com.company;

import java.util.ArrayList;
import java.util.List;

public class YoutubeChannel implements Observable{
    List<String> videos = new ArrayList<>();

    List <Observer> subscribers = new ArrayList<>();

    public void addVideo(String video) {
        this.videos.add(video);
        notificate();
    }

    public void removeVideo(String video) {
        this.videos.remove(video);
        notificate();
    }

    @Override
    public void addObserver(Observer subscriber) {
        this.subscribers.add(subscriber);
    }

    @Override
    public void removeObserver(Observer subscriber) {
        this.subscribers.remove(subscriber);
    }

    @Override
    public void notificate() {
        for(Observer subscriber: subscribers){
            subscriber.execute(videos);
        }
    }
}
