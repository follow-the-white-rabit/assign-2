package com.company;

import java.util.List;

public class YoutubeUser implements Observer{
    private String username;

    public YoutubeUser(String username){
        this.username = username;
    }

    @Override
    public void execute(List<String> videos) {
        System.out.println("Dear " + username + ",\n " +
                "we have some changes in our videos:\n "+
                videos + "\n" +
                "========================================");
        System.out.println();
    }
}
