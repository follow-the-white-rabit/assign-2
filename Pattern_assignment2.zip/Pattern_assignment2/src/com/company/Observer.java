package com.company;

import java.util.List;

public interface Observer {
    void execute(List<String> videos);
}
