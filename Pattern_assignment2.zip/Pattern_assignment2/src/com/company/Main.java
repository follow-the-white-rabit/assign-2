package com.company;

public class Main {

    public static void main(String[] args) {
        YoutubeChannel NatGeoWild = new YoutubeChannel();

        YoutubeUser user1 = new YoutubeUser("Dias");
        NatGeoWild.addObserver(user1);

        NatGeoWild.addVideo("Wild Cats");
        NatGeoWild.addVideo("Safari");

        NatGeoWild.addObserver(new YoutubeUser("Samat"));
        NatGeoWild.addObserver(new YoutubeUser("Zhanar"));

        NatGeoWild.addVideo("Random");

        NatGeoWild.removeObserver(user1);

        NatGeoWild.removeVideo("Random");
    }
}
